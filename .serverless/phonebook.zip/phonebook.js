'use strict';

const phonebook = [
  {
    id: 0,
    name: 'Kemo',
    lastname: 'Sminker',
    phone: '071 534-097'
  },
  {
    id: 1,
    name: 'Lesi',
    lastname: 'Ker',
    phone: '071 236-589'
  },
  {
    id: 2,
    name: 'Hamo',
    lastname: 'Bolikurac',
    phone: '071 4353-5111'
  }
]

module.exports.phonebook = phonebook;